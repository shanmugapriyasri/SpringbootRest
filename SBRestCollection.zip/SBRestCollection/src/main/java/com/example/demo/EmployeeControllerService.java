package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class EmployeeControllerService {
	
	static EmployeeDao employeeDao=new EmployeeDao();
	//http://localhost:8080/allemp
	@GetMapping("/allemp")
	public List<Employee> getAllEmp(){
		System.out.println("controller-all");
		List<Employee> emplist=employeeDao.getAllemployee();
		return emplist;
	}
	//http://localhost:8080/E04
	@GetMapping("/{eid}")
	public ResponseEntity getById(@PathVariable("eid")String eid){
		Employee emp=employeeDao.getbyid(eid);
		
	        return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		
	}
	//method-PUT -> body raw- type application/json
	//http://localhost:8080/update
	@PutMapping("/update")
	public Employee update(@RequestBody Employee e){
		Employee emp=employeeDao.updateEmployee(e);
		return emp;
	}
	//Method->delete
	//http://localhost:8080/delete/E02
	
	@DeleteMapping("/delete/{eid}")
	public String delete(@PathVariable("eid")String eid){
		employeeDao.deleteEmployee(eid);
		return eid+" Deleted";
	}
	//method-post
	//http://localhost:8080/add 
	//body ->raw->application/json
	@PostMapping("/add")
	public Employee addemp(@RequestBody Employee employee){
		Employee e=new Employee(employee.getEid(), employee.getName(), employee.getPost());
		Employee emp=employeeDao.addEmployee(e);
		return emp;
	}
	
}
	

