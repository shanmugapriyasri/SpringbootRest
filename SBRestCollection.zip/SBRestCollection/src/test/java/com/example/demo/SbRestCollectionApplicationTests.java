package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.junit.runner.Runner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;

//@SpringBootTest
@WebMvcTest
@RunWith(SpringRunner.class)
class SbRestCollectionApplicationTests {
	@Autowired
	EmployeeControllerService controller;

	@Autowired
	private MockMvc mvc;
	
	@Test
	void contextLoads() {
		assertThat(controller).isNotNull();
	}

	

	 
	@Test
	public void getAllEmployeesAPI() throws Exception 
	{
	  mvc.perform( MockMvcRequestBuilders
	      .get("/allemp")
	      .accept(MediaType.APPLICATION_JSON))
	      .andDo(print())
	      .andExpect(status().isOk())
	      .andExpect(MockMvcResultMatchers.jsonPath("$").exists())
	      .andExpect(MockMvcResultMatchers.jsonPath("$[0].eid").isNotEmpty());
	     // .andExpect(MockMvcResultMatchers.jsonPath("$").value(4));
	}
	
	
	@Test
	public void getEmployeeByIdAPI() throws Exception 
	{
	  mvc.perform( MockMvcRequestBuilders
	      .get("/{eid}", "E01")
	      .accept(MediaType.APPLICATION_JSON))
	      .andDo(print())
	      .andExpect(status().isOk())
	      .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("priya"));
	}
	
	@Test
	public void createEmployeeAPI() throws Exception 
	{
	  mvc.perform( MockMvcRequestBuilders
	      .post("/add")
	      .content(asJsonString(new Employee("E33", "firstName4", "manager")))
	      .contentType(MediaType.APPLICATION_JSON)
	      .accept(MediaType.APPLICATION_JSON))
	  .andExpect(status().isOk())
	  .andExpect(MockMvcResultMatchers.jsonPath("$").exists())
	  .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("firstName4"));
	      //.andExpect(status().isCreated());
	    //  .andExpect(MockMvcResultMatchers.jsonPath("$.employeeId").exists());
	}
	
	public static String asJsonString(final Object obj) {
	    try {
	        return new ObjectMapper().writeValueAsString(obj);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
}
